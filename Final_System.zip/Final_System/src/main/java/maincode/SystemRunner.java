/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maincode;

import java.util.ArrayList;
public class SystemRunner {
    
      public static ArrayList<String> items = new ArrayList<>(
    java.util.Arrays.asList(
        "Lumpia wrapper",
        "Patatasan",
        "Tawgi", 
        "Pakbit",
        "Sari Sari",
        "Pinansitan"
    )
); 
      public static ArrayList<String> reservations = new ArrayList<>();
      public static ArrayList<String> transactionHistory = new ArrayList<>();
      public static ArrayList<String> archivedReservations = new ArrayList<>();
      public static ArrayList<String> archiveDates = new ArrayList<>();
public static void main(String[] args) {

    new CustomerGui.LoginGui().setVisible(true);
}
}
