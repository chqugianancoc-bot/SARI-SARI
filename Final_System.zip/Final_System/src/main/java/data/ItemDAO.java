package data;

import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ItemDAO {

    public static ArrayList<String> getItems() {

        ArrayList<String> items = new ArrayList<>();

        String sql = "SELECT item_name FROM items "
                + "WHERE status = 'active' "
                + "ORDER BY item_id";

        try {

            Connection con = DBConnection.getConnection();
            PreparedStatement pst = con.prepareStatement(sql);

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {

                items.add(rs.getString("item_name"));
            }

            con.close();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return items;
    }
    public static ArrayList<String> getPrices(String itemName) {

    ArrayList<String> prices = new ArrayList<>();

    String sql = "SELECT variant_name, price "
            + "FROM item_variants "
            + "WHERE item_id = ("
            + "SELECT item_id FROM items WHERE item_name = ?"
            + ") "
            + "AND status = 'active'";

    try {

        Connection con = DBConnection.getConnection();
        PreparedStatement pst = con.prepareStatement(sql);

        pst.setString(1, itemName);

        ResultSet rs = pst.executeQuery();

        while (rs.next()) {

            String variant =
                    rs.getString("variant_name");

            double price =
                    rs.getDouble("price");

            prices.add(
                    variant + "|" + price
            );
        }

        con.close();

    } catch (Exception e) {

        e.printStackTrace();
    }

    return prices;
}public static boolean addItem(String itemName, double price) {

    // VALIDATION
    if (itemName == null || itemName.trim().isEmpty()) {
        return false;
    }

    if (price <= 0) {
        return false;
    }

    String checkSql =
            "SELECT item_id FROM items WHERE item_name = ?";

    String insertItemSql =
            "INSERT INTO items (item_name) VALUES (?)";

    String insertPriceSql =
            "INSERT INTO item_variants "
            + "(item_id, variant_name, price) "
            + "VALUES (?, 'Regular', ?)";

    Connection con = null;

    try {

        con = DBConnection.getConnection();

        // START TRANSACTION
        con.setAutoCommit(false);

        // CHECK IF ITEM ALREADY EXISTS
        PreparedStatement check =
                con.prepareStatement(checkSql);

        check.setString(1, itemName.trim());

        ResultSet rs =
                check.executeQuery();

        if (rs.next()) {

            con.rollback();
            con.close();

            return false;
        }

        // INSERT ITEM
        PreparedStatement itemPst =
                con.prepareStatement(
                        insertItemSql,
                        java.sql.Statement.RETURN_GENERATED_KEYS
                );

        itemPst.setString(1, itemName.trim());

        int itemRows =
                itemPst.executeUpdate();

        if (itemRows <= 0) {

            con.rollback();
            con.close();

            return false;
        }

        // GET GENERATED ITEM ID
        ResultSet keys =
                itemPst.getGeneratedKeys();

        if (!keys.next()) {

            con.rollback();
            con.close();

            return false;
        }

        int itemId =
                keys.getInt(1);

        // INSERT REGULAR VARIANT
        PreparedStatement pricePst =
                con.prepareStatement(insertPriceSql);

        pricePst.setInt(1, itemId);
        pricePst.setDouble(2, price);

        int priceRows =
                pricePst.executeUpdate();

        if (priceRows <= 0) {

            con.rollback();
            con.close();

            return false;
        }

        // BOTH INSERTS SUCCESSFUL
        con.commit();

        con.close();

        return true;

    } catch (Exception e) {

        e.printStackTrace();

        try {

            if (con != null) {
                con.rollback();
                con.close();
            }

        } catch (Exception rollbackError) {

            rollbackError.printStackTrace();
        }

        return false;
    }
}
public static boolean itemExists(String itemName) {

    String sql =
            "SELECT item_id FROM items WHERE item_name = ?";

    try {

        Connection con =
                DBConnection.getConnection();

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setString(1, itemName);

        ResultSet rs =
                pst.executeQuery();

        boolean exists = rs.next();

        con.close();

        return exists;

    } catch (Exception e) {

        e.printStackTrace();

        return false;
    }
}
public static int getVariantId(
        String itemName,
        String variantName) {

    // VALIDATION 1: item name
    if (itemName == null || itemName.trim().isEmpty()) {
        return -1;
    }

    // VALIDATION 2: variant name
    if (variantName == null || variantName.trim().isEmpty()) {
        return -1;
    }

    String sql =
            "SELECT iv.variant_id "
            + "FROM item_variants iv "
            + "JOIN items i "
            + "ON iv.item_id = i.item_id "
            + "WHERE i.item_name = ? "
            + "AND iv.variant_name = ? "
            + "AND i.status = 'active' "
            + "AND iv.status = 'active'";

    try {

        Connection con =
                DBConnection.getConnection();

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setString(1, itemName.trim());
        pst.setString(2, variantName.trim());

        ResultSet rs =
                pst.executeQuery();

        if (rs.next()) {

            int variantId =
                    rs.getInt("variant_id");

            con.close();

            return variantId;
        }

        con.close();

    } catch (Exception e) {

        e.printStackTrace();
    }

    return -1;
}
 
}