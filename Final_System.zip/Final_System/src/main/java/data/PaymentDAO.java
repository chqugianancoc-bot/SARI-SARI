package data;

import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class PaymentDAO {

    public static boolean savePayment(
            int reservationId,
            String referenceNumber,
            double amount) {

        // VALIDATION 1: reservation ID
        if (reservationId <= 0) {
            return false;
        }

        // VALIDATION 2: reference number
        if (referenceNumber == null
                || referenceNumber.trim().isEmpty()) {
            return false;
        }

        // VALIDATION 3: payment amount
        if (amount <= 0) {
            return false;
        }

        String sql =
                "INSERT INTO payments "
                + "(reservation_id, payment_method, "
                + "reference_number, amount, payment_status) "
                + "VALUES (?, 'GCash', ?, ?, 'PENDING')";

        try {

            Connection con =
                    DBConnection.getConnection();

            PreparedStatement pst =
                    con.prepareStatement(sql);

            pst.setInt(1, reservationId);
            pst.setString(2, referenceNumber.trim());
            pst.setDouble(3, amount);

            pst.executeUpdate();

            con.close();

            return true;

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }
    public static boolean verifyPayment(int reservationId) {

    // VALIDATION 1: reservation ID
    if (reservationId <= 0) {
        return false;
    }

    String sql =
            "UPDATE payments "
            + "SET payment_status = 'VERIFIED', "
            + "paid_at = NOW() "
            + "WHERE reservation_id = ? "
            + "AND payment_status = 'PENDING'";

    try {
        Connection con = DBConnection.getConnection();

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setInt(1, reservationId);

        int rowsUpdated =
                pst.executeUpdate();

        con.close();

        return rowsUpdated > 0;

    } catch (Exception e) {

        e.printStackTrace();
        return false;
    }
}public static boolean verifyPaymentAndReservation(int reservationId) {

    if (reservationId <= 0) {
        return false;
    }

    Connection con = null;

    try {

        con = DBConnection.getConnection();

        // START TRANSACTION
        con.setAutoCommit(false);

        // VERIFY PAYMENT
        String paymentSql =
                "UPDATE payments "
                + "SET payment_status = 'VERIFIED', "
                + "paid_at = NOW() "
                + "WHERE reservation_id = ? "
                + "AND payment_status = 'PENDING'";

        PreparedStatement paymentPst =
                con.prepareStatement(paymentSql);

        paymentPst.setInt(1, reservationId);

        int paymentUpdated =
                paymentPst.executeUpdate();

        if (paymentUpdated <= 0) {
            con.rollback();
            con.close();
            return false;
        }

        // VERIFY RESERVATION
        String reservationSql =
                "UPDATE reservations "
                + "SET status = 'PAYMENT VERIFIED' "
                + "WHERE reservation_id = ? "
                + "AND status = 'PAYMENT PENDING'";

        PreparedStatement reservationPst =
                con.prepareStatement(reservationSql);

        reservationPst.setInt(1, reservationId);

        int reservationUpdated =
                reservationPst.executeUpdate();

        if (reservationUpdated <= 0) {
            con.rollback();
            con.close();
            return false;
        }

        // BOTH SUCCEEDED
        con.commit();

        con.close();

        return true;

    } catch (Exception e) {

        e.printStackTrace();

        try {
            if (con != null) {
                con.rollback();
                con.close();
            }
        } catch (Exception rollbackError) {
            rollbackError.printStackTrace();
        }

        return false;
    }
}
}