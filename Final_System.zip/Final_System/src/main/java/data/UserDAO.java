package data;

import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class UserDAO {

    // CREATE USER
    public static boolean createUser(
            String firstName,
            String lastName,
            String contact,
            String email,
            String address,
            String username,
            String password) {

        String sql = "INSERT INTO users "
                + "(first_name, last_name, contact, email, address, username, password, role) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, 'USER')";

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement pst = con.prepareStatement(sql);

            pst.setString(1, firstName);
            pst.setString(2, lastName);
            pst.setString(3, contact);
            pst.setString(4, email);
            pst.setString(5, address);
            pst.setString(6, username);
            pst.setString(7, password);

            pst.executeUpdate();

            con.close();

            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // LOGIN USER
    public static boolean loginUser(
            String username,
            String password) {

        String sql = "SELECT * FROM users "
                + "WHERE username = ? AND password = ? "
                + "AND role = 'USER' "
                + "AND status = 'active'";

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement pst = con.prepareStatement(sql);

            pst.setString(1, username);
            pst.setString(2, password);

            var rs = pst.executeQuery();

            boolean found = rs.next();

            con.close();

            return found;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    public static int getUserId(String username) {

    if (username == null || username.trim().isEmpty()) {
        return -1;
    }

    String sql = "SELECT user_id FROM users "
            + "WHERE username = ? "
            + "AND role = 'USER' "
            + "AND status = 'active'";

    try {

        Connection con = DBConnection.getConnection();

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setString(1, username.trim());

        var rs = pst.executeQuery();

        if (rs.next()) {
            return rs.getInt("user_id");
        }

        con.close();

    } catch (Exception e) {

        e.printStackTrace();
    }

    return -1;
}
    // CHECK IF USERNAME EXISTS
    public static boolean usernameExists(String username) {

        String sql = "SELECT * FROM users "
                + "WHERE username = ? "
                + "AND role = 'USER'";

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement pst = con.prepareStatement(sql);

            pst.setString(1, username);

            var rs = pst.executeQuery();

            boolean found = rs.next();

            con.close();

            return found;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // CHECK IF EMAIL MATCHES USERNAME
    public static boolean emailMatches(
            String username,
            String email) {

        String sql = "SELECT * FROM users "
                + "WHERE username = ? "
                + "AND email = ? "
                + "AND role = 'USER'";

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement pst = con.prepareStatement(sql);

            pst.setString(1, username);
            pst.setString(2, email);

            var rs = pst.executeQuery();

            boolean found = rs.next();

            con.close();

            return found;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // RESET PASSWORD
    public static boolean resetPassword(
            String username,
            String email,
            String newPassword) {

        String sql = "UPDATE users "
                + "SET password = ? "
                + "WHERE username = ? "
                + "AND email = ? "
                + "AND role = 'USER'";

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement pst = con.prepareStatement(sql);

            pst.setString(1, newPassword);
            pst.setString(2, username);
            pst.setString(3, email);

            int rows = pst.executeUpdate();

            con.close();

            return rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}