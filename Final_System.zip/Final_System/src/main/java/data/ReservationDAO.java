package data;

import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Date;

public class ReservationDAO {
    

  
    public static int createReservation(
        int userId,
        Date orderDate,
        Date reservationDate) {

    // VALIDATION 1: user ID
    if (userId <= 0) {
        return -1;
    }

    // VALIDATION 2: dates must not be null
    if (orderDate == null || reservationDate == null) {
        return -1;
    }

    // VALIDATION 3: reservation must be tomorrow or later
    Date tomorrow = Date.valueOf(
            java.time.LocalDate.now().plusDays(1)
    );

    if (reservationDate.before(tomorrow)) {
        return -1;
    }

    String sql =
            "INSERT INTO reservations "
            + "(user_id, order_date, reservation_date, status) "
            + "VALUES (?, ?, ?, 'PAYMENT PENDING')";

    try {

        Connection con =
                DBConnection.getConnection();

        PreparedStatement pst =
                con.prepareStatement(
                        sql,
                        java.sql.Statement.RETURN_GENERATED_KEYS
                );

        pst.setInt(1, userId);
        pst.setDate(2, orderDate);
        pst.setDate(3, reservationDate);

        pst.executeUpdate();

        ResultSet rs =
                pst.getGeneratedKeys();

        if (rs.next()) {

            int reservationId =
                    rs.getInt(1);

            con.close();

            return reservationId;
        }

        con.close();

    } catch (Exception e) {

        e.printStackTrace();
    }

    return -1;
}public static boolean saveReservationItem(
        int reservationId,
        int variantId,
        int quantity,
        double unitPrice) {

    // VALIDATION 1: reservation ID
    if (reservationId <= 0) {
        return false;
    }

    // VALIDATION 2: variant ID
    if (variantId <= 0) {
        return false;
    }

    // VALIDATION 3: quantity
    if (quantity <= 0) {
        return false;
    }

    // VALIDATION 4: price
    if (unitPrice <= 0) {
        return false;
    }

    double subtotal = unitPrice * quantity;

    String sql =
            "INSERT INTO reservation_items "
            + "(reservation_id, variant_id, quantity, unit_price, subtotal) "
            + "VALUES (?, ?, ?, ?, ?)";

    try {

        Connection con =
                DBConnection.getConnection();

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setInt(1, reservationId);
        pst.setInt(2, variantId);
        pst.setInt(3, quantity);
        pst.setDouble(4, unitPrice);
        pst.setDouble(5, subtotal);

        pst.executeUpdate();

        con.close();

        return true;

    } catch (Exception e) {

        e.printStackTrace();

        return false;
    }
}
   
   public static ResultSet getSellerReservations() {

    String sql =
            "SELECT r.reservation_id, "
            + "CONCAT(u.first_name, ' ', u.last_name) AS customer, "
            + "r.reservation_date, "
            + "p.reference_number, "
            + "r.status, "
            + "p.payment_status "
            + "FROM reservations r "
            + "JOIN users u "
            + "ON r.user_id = u.user_id "
            + "LEFT JOIN payments p "
            + "ON r.reservation_id = p.reservation_id "
            + "WHERE (r.status = 'PAYMENT PENDING' "
            + "OR r.status = 'PAYMENT VERIFIED') "
            + "ORDER BY r.reservation_id ASC";

    try {

        Connection con =
                DBConnection.getConnection();

        PreparedStatement pst =
                con.prepareStatement(sql);

        return pst.executeQuery();

    } catch (Exception e) {

        e.printStackTrace();
        return null;
    }
}
    public static boolean verifyReservation(int reservationId) {

    // VALIDATION 1: reservation ID
    if (reservationId <= 0) {
        return false;
    }

    String sql =
            "UPDATE reservations "
            + "SET status = 'PAYMENT VERIFIED' "
            + "WHERE reservation_id = ? "
            + "AND status = 'PAYMENT PENDING'";

    try {

        Connection con =
                DBConnection.getConnection();

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setInt(1, reservationId);

        int rowsUpdated =
                pst.executeUpdate();

        con.close();

        return rowsUpdated > 0;

    } catch (Exception e) {

        e.printStackTrace();
        return false;
    }
}
    public static boolean claimReservation(int reservationId) {

    // VALIDATION 1: reservation ID
    if (reservationId <= 0) {
        return false;
    }

    String sql =
            "UPDATE reservations "
            + "SET status = 'CLAIMED' "
            + "WHERE reservation_id = ? "
            + "AND status = 'PAYMENT VERIFIED'";

    try {

        Connection con =
                DBConnection.getConnection();

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setInt(1, reservationId);

        int rowsUpdated =
                pst.executeUpdate();

        con.close();

        return rowsUpdated > 0;

    } catch (Exception e) {

        e.printStackTrace();
        return false;
    }
}
   public static ResultSet getTransactionHistory() {

    String sql =
            "SELECT r.reservation_id, "
            + "CONCAT(u.first_name, ' ', u.last_name) AS customer, "
            + "r.reservation_date, "
            + "r.status, "
            + "SUM(ri.subtotal) AS total, "
            + "SUM(ri.subtotal) * 0.50 AS deposit, "
            + "SUM(ri.subtotal) * 0.50 AS balance, "
            + "GROUP_CONCAT("
            + "CONCAT(i.item_name, ' x', ri.quantity)"
            + " SEPARATOR ', '"
            + ") AS items "
            + "FROM reservations r "
            + "JOIN users u "
            + "ON r.user_id = u.user_id "
            + "JOIN reservation_items ri "
            + "ON r.reservation_id = ri.reservation_id "
            + "JOIN item_variants iv "
            + "ON ri.variant_id = iv.variant_id "
            + "JOIN items i "
            + "ON iv.item_id = i.item_id "
            + "WHERE r.status <> 'PAYMENT PENDING' "
            + "GROUP BY r.reservation_id, "
            + "u.first_name, u.last_name, "
            + "r.reservation_date, r.status "
            + "ORDER BY r.reservation_id DESC";

    try {

        Connection con =
                DBConnection.getConnection();

        PreparedStatement pst =
                con.prepareStatement(sql);

        return pst.executeQuery();

    } catch (Exception e) {

        e.printStackTrace();
        return null;
    }
}
   public static ResultSet getArchives() {

    String sql =
            "SELECT a.archive_id, "
            + "r.reservation_id, "
            + "CONCAT(u.first_name, ' ', u.last_name) AS customer, "
            + "r.reservation_date, "
            + "r.status, "
            + "SUM(ri.subtotal) AS total, "
            + "SUM(ri.subtotal) * 0.50 AS deposit, "
            + "SUM(ri.subtotal) * 0.50 AS balance, "
            + "GROUP_CONCAT("
            + "CONCAT(i.item_name, ' x', ri.quantity)"
            + " SEPARATOR ', '"
            + ") AS items, "
            + "a.reason, "
            + "a.archived_at "
            + "FROM archives a "
            + "JOIN reservations r "
            + "ON a.reservation_id = r.reservation_id "
            + "JOIN users u "
            + "ON r.user_id = u.user_id "
            + "LEFT JOIN reservation_items ri "
            + "ON r.reservation_id = ri.reservation_id "
            + "LEFT JOIN item_variants iv "
            + "ON ri.variant_id = iv.variant_id "
            + "LEFT JOIN items i "
            + "ON iv.item_id = i.item_id "
            + "GROUP BY a.archive_id, "
            + "r.reservation_id, "
            + "u.first_name, u.last_name, "
            + "r.reservation_date, "
            + "r.status, "
            + "a.reason, "
            + "a.archived_at "
            + "ORDER BY a.archive_id DESC";

    try {
        Connection con = DBConnection.getConnection();
        PreparedStatement pst =
                con.prepareStatement(sql);

        return pst.executeQuery();

    } catch (Exception e) {
        e.printStackTrace();
        return null;
    }
}
   public static boolean deleteOldArchives() {

    String sql =
            "DELETE FROM archives "
            + "WHERE archived_at <= "
            + "DATE_SUB(NOW(), INTERVAL 30 DAY)";

    try {
        Connection con = DBConnection.getConnection();
        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.executeUpdate();

        con.close();

        return true;

    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}
   public static boolean archiveReservation(
        int reservationId,
        String reason) {

    if (reservationId <= 0) {
        return false;
    }

    if (reason == null || reason.trim().isEmpty()) {
        return false;
    }

    String sql =
            "INSERT INTO archives "
            + "(reservation_id, reason) "
            + "VALUES (?, ?)";

    try {
        Connection con = DBConnection.getConnection();
        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setInt(1, reservationId);
        pst.setString(2, reason.trim());

        int rows = pst.executeUpdate();

        con.close();

        return rows > 0;

    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}
   public static boolean restoreReservation(
        int reservationId,
        String status) {

    if (reservationId <= 0) {
        return false;
    }

    if (status == null || status.trim().isEmpty()) {
        return false;
    }

    if (!status.equals("PAYMENT PENDING")
            && !status.equals("PAYMENT VERIFIED")
            && !status.equals("CLAIMED")) {
        return false;
    }

    String sql =
            "UPDATE reservations "
            + "SET status = ? "
            + "WHERE reservation_id = ?";

    try {
        Connection con = DBConnection.getConnection();
        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setString(1, status);
        pst.setInt(2, reservationId);

        int rows = pst.executeUpdate();

        con.close();

        return rows > 0;

    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}
   public static boolean markAsArchived(int reservationId) {

    // Validation
    if (reservationId <= 0) {
        return false;
    }

    String sql =
            "UPDATE reservations "
            + "SET status = 'ARCHIVED' "
            + "WHERE reservation_id = ? "
            + "AND status <> 'ARCHIVED'";

    try {
        Connection con = DBConnection.getConnection();
        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setInt(1, reservationId);

        int rows = pst.executeUpdate();

        con.close();

        return rows > 0;

    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}
   public static boolean removeFromArchives(int reservationId) {

    if (reservationId <= 0) {
        return false;
    }

    String sql =
            "DELETE FROM archives "
            + "WHERE reservation_id = ?";

    try {
        Connection con = DBConnection.getConnection();
        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setInt(1, reservationId);

        int rows = pst.executeUpdate();

        con.close();

        return rows > 0;

    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}
   public static boolean rollbackReservation(int reservationId) {

    // Validation
    if (reservationId <= 0) {
        return false;
    }

    String deleteItems =
            "DELETE FROM reservation_items "
            + "WHERE reservation_id = ?";

    String deleteReservation =
            "DELETE FROM reservations "
            + "WHERE reservation_id = ? "
            + "AND status = 'PAYMENT PENDING'";

    try {
        Connection con = DBConnection.getConnection();

        // Start transaction
        con.setAutoCommit(false);

        PreparedStatement pstItems =
                con.prepareStatement(deleteItems);

        pstItems.setInt(1, reservationId);
        pstItems.executeUpdate();

        PreparedStatement pstReservation =
                con.prepareStatement(deleteReservation);

        pstReservation.setInt(1, reservationId);

        int rows =
                pstReservation.executeUpdate();

        if (rows <= 0) {
            con.rollback();
            con.setAutoCommit(true);
            con.close();
            return false;
        }

        con.commit();
        con.setAutoCommit(true);
        con.close();

        return true;

    } catch (Exception e) {

        e.printStackTrace();

        return false;
    }
}
   public static ResultSet getUserReservations(String username) {

    if (username == null || username.trim().isEmpty()) {
        return null;
    }

    String sql =
            "SELECT r.reservation_id, "
            + "r.order_date, "
            + "r.reservation_date, "
            + "r.status, "
            + "GROUP_CONCAT("
            + "CONCAT(i.item_name, ' x', ri.quantity)"
            + " SEPARATOR ', '"
            + ") AS items "
            + "FROM reservations r "
            + "JOIN users u "
            + "ON r.user_id = u.user_id "
            + "LEFT JOIN reservation_items ri "
            + "ON r.reservation_id = ri.reservation_id "
            + "LEFT JOIN item_variants iv "
            + "ON ri.variant_id = iv.variant_id "
            + "LEFT JOIN items i "
            + "ON iv.item_id = i.item_id "
            + "WHERE u.username = ? "
            + "AND r.status <> 'ARCHIVED' "
            + "AND r.status <> 'CANCELLED' "
            + "GROUP BY r.reservation_id, "
            + "r.order_date, "
            + "r.reservation_date, "
            + "r.status "
            + "ORDER BY r.reservation_id DESC";

    try {

        Connection con =
                DBConnection.getConnection();

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setString(1, username.trim());

        return pst.executeQuery();

    } catch (Exception e) {

        e.printStackTrace();

        return null;
    }
}public static ResultSet getReservationPaymentDetails(int reservationId) {

    // VALIDATION 1: reservation ID
    if (reservationId <= 0) {
        return null;
    }

    String sql =
            "SELECT "
            + "SUM(ri.subtotal) AS total_price, "
            + "SUM(ri.subtotal) * 0.50 AS down_payment, "
            + "SUM(ri.subtotal) * 0.50 AS remaining_balance "
            + "FROM reservation_items ri "
            + "WHERE ri.reservation_id = ?";

    try {

        Connection con =
                DBConnection.getConnection();

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setInt(1, reservationId);

        return pst.executeQuery();

    } catch (Exception e) {

        e.printStackTrace();

        return null;
    }
}
   public static boolean cancelReservation(
        int reservationId,
        int userId) {

    // VALIDATION: reservation ID
    if (reservationId <= 0) {
        return false;
    }

    // VALIDATION: user ID
    if (userId <= 0) {
        return false;
    }

    String checkSql =
            "SELECT status "
            + "FROM reservations "
            + "WHERE reservation_id = ? "
            + "AND user_id = ?";

    String archiveSql =
            "INSERT INTO archives "
            + "(reservation_id, reason) "
            + "VALUES (?, 'Cancelled by customer')";

    String cancelSql =
            "UPDATE reservations "
            + "SET status = 'CANCELLED' "
            + "WHERE reservation_id = ? "
            + "AND user_id = ? "
            + "AND status = 'PAYMENT PENDING'";

    Connection con = null;

    try {

        con = DBConnection.getConnection();
        con.setAutoCommit(false);

        // Check reservation first
        PreparedStatement checkPst =
                con.prepareStatement(checkSql);

        checkPst.setInt(1, reservationId);
        checkPst.setInt(2, userId);

        ResultSet rs =
                checkPst.executeQuery();

        if (!rs.next()) {
            con.rollback();
            con.close();
            return false;
        }

        String status =
                rs.getString("status");

        // VALIDATION: only PAYMENT PENDING
        if (!"PAYMENT PENDING".equals(status)) {
            con.rollback();
            con.close();
            return false;
        }

        // Change status to CANCELLED
        PreparedStatement cancelPst =
                con.prepareStatement(cancelSql);

        cancelPst.setInt(1, reservationId);
        cancelPst.setInt(2, userId);

        int updated =
                cancelPst.executeUpdate();

        // VALIDATION: reservation must be updated
        if (updated <= 0) {
            con.rollback();
            con.close();
            return false;
        }

        // Add to Archives
        PreparedStatement archivePst =
                con.prepareStatement(archiveSql);

        archivePst.setInt(1, reservationId);

        int archived =
                archivePst.executeUpdate();

        // VALIDATION: archive must be created
        if (archived <= 0) {
            con.rollback();
            con.close();
            return false;
        }

        con.commit();
        con.setAutoCommit(true);
        con.close();

        return true;

    } catch (Exception e) {

        e.printStackTrace();

        try {
            if (con != null) {
                con.rollback();
                con.close();
            }
        } catch (Exception rollbackError) {
            rollbackError.printStackTrace();
        }

        return false;
    }
}
   public static ResultSet getCustomerArchives(String username) {

    // Validation
    if (username == null || username.trim().isEmpty()) {
        return null;
    }

    String sql =
        "SELECT a.archive_id, "
        + "r.reservation_id, "
        + "r.order_date, "
        + "r.reservation_date, "
        + "r.status, "
        + "GROUP_CONCAT(CONCAT(i.item_name, ' x', ri.quantity) "
        + "SEPARATOR ', ') AS items, "
        + "a.reason, "
        + "a.archived_at "
        + "FROM archives a "
        + "JOIN reservations r ON a.reservation_id = r.reservation_id "
        + "JOIN users u ON r.user_id = u.user_id "
        + "LEFT JOIN reservation_items ri "
        + "ON r.reservation_id = ri.reservation_id "
        + "LEFT JOIN item_variants iv "
        + "ON ri.variant_id = iv.variant_id "
        + "LEFT JOIN items i "
        + "ON iv.item_id = i.item_id "
        + "WHERE u.username = ? "
        + "AND r.status = 'CANCELLED' "
        + "GROUP BY a.archive_id, "
        + "r.reservation_id, "
        + "r.order_date, "
        + "r.reservation_date, "
        + "r.status, "
        + "a.reason, "
        + "a.archived_at "
        + "ORDER BY a.archive_id DESC";

    try {
        Connection con = DBConnection.getConnection();

        PreparedStatement pst = con.prepareStatement(sql);
        pst.setString(1, username.trim());

        return pst.executeQuery();

    } catch (Exception e) {
        e.printStackTrace();
        return null;
    }
}
   public static ResultSet getReservationDetails(int reservationId) {

    // VALIDATION: reservation ID
    if (reservationId <= 0) {
        return null;
    }

    String sql =
            "SELECT r.reservation_id, "
            + "CONCAT(u.first_name, ' ', u.last_name) AS customer, "
            + "r.order_date, "
            + "r.reservation_date, "
            + "r.status, "
            + "ri.quantity, "
            + "ri.unit_price, "
            + "ri.subtotal, "
            + "i.item_name, "
            + "iv.variant_name "
            + "FROM reservations r "
            + "JOIN users u "
            + "ON r.user_id = u.user_id "
            + "JOIN reservation_items ri "
            + "ON r.reservation_id = ri.reservation_id "
            + "JOIN item_variants iv "
            + "ON ri.variant_id = iv.variant_id "
            + "JOIN items i "
            + "ON iv.item_id = i.item_id "
            + "WHERE r.reservation_id = ?";

    try {

        Connection con =
                DBConnection.getConnection();

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setInt(1, reservationId);

        return pst.executeQuery();

    } catch (Exception e) {

        e.printStackTrace();

        return null;
    }
}
   public static ResultSet searchSellerReservations(
        String month,
        String status) {

    // VALIDATION 1: month
    if (month == null || month.trim().isEmpty()) {
        return null;
    }

    // VALIDATION 2: month format
    if (!month.matches("\\d{4}-(0[1-9]|1[0-2])")) {
        return null;
    }

    // VALIDATION 3: status
    if (status == null || status.trim().isEmpty()) {
        return null;
    }

    String sql =
            "SELECT r.reservation_id, "
            + "CONCAT(u.first_name, ' ', u.last_name) AS customer, "
            + "r.reservation_date, "
            + "p.reference_number, "
            + "r.status, "
            + "p.payment_status "
            + "FROM reservations r "
            + "JOIN users u "
            + "ON r.user_id = u.user_id "
            + "LEFT JOIN payments p "
            + "ON r.reservation_id = p.reservation_id "
            + "WHERE r.status <> 'ARCHIVED' "
            + "AND r.status <> 'CANCELLED' "
            + "AND DATE_FORMAT(r.reservation_date, '%Y-%m') = ? ";

    if (!status.equals("ALL")) {
        sql += "AND r.status = ? ";
    }

    sql += "ORDER BY r.reservation_id DESC";

    try {

        Connection con =
                DBConnection.getConnection();

        PreparedStatement pst =
                con.prepareStatement(sql);

        pst.setString(1, month.trim());

        if (!status.equals("ALL")) {
            pst.setString(2, status.trim());
        }

        return pst.executeQuery();

    } catch (Exception e) {

        e.printStackTrace();

        return null;
    }
}
   
}