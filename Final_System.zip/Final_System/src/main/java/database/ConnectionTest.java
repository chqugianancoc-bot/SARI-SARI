package database;

import java.sql.Connection;

public class ConnectionTest {

    public static void main(String[] args) {

        try {
            Connection con = DBConnection.getConnection();

            System.out.println("DATABASE CONNECTED!");

            con.close();

        } catch (Exception e) {
            System.out.println("CONNECTION FAILED!");
            e.printStackTrace();
        }
    }
}